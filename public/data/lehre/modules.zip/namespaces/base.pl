#!/usr/bin/perl -w

$name1 = "Andi";
$name2 = "Max";
$name3 = "Markus";

$names = [$name1, $name2, $name3];

print join("\n",@$names);

