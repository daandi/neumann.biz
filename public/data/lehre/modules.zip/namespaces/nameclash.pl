#!/usr/bin/perl -w

$name1 = "Andi";
$name2 = "Max";
$name3 = "Markus";

require "additional_names.pl";

$names = [$name1, $name2, $name3];

print join("\n",@$names);

