#!/usr/bin/perl 

$name1 = "Andi";
$name2 = "Max";
$name3 = "Markus";

require "additional_names_done_right.pl";
$names = [$name1, $name2, $name3];
print join("\n",@$names);


#Auf Variable aus anderem Namespace zugreifen
print "\n".$AdditionalNames::name1."\n";

# Auf eine Methode/Funktion im Namespace zugreifen
AdditionalNames -> say_hello();
AdditionalNames::say_hello();



