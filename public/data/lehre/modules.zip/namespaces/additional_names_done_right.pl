#!/usr/bin/perl 
package AdditionalNames;
$name1 = "Chopy";
$name2 = "Max";
$name3 = "Momo";

sub say_hello {
	print("Hello\n");
}
