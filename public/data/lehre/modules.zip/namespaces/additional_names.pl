#!/usr/bin/perl 

$name1 = "Chopy";
$name2 = "Max";
$name3 = "Momo";
