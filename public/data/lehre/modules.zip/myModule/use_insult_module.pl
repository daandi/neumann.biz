#!/usr/bin/perl -w
use insult; # Funktioniert weil "." teil von @INC

cow();
cow_reposte();

# nicht exportierte Methoden nicht zugreifbar
# hello();