#!/usr/bin/perl -w

package insult;
use Exporter;
@ISA = ("Exporter");
@EXPORT = ("cow","cow_reposte");

sub cow {
	print "You fight like a dairy farmer.\n";
}

sub cow_reposte {
	print "How appropriate. You fight like a cow.\n";
}

sub hello {
	print("I'm selling these coll leather-jackets!")
}

1;