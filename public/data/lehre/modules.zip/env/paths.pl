#!/usr/bin/perl -w
# Im Array INC werden alle Pfade angegeben in denen nach modulen gesucht wird
foreach (@INC) {
	print "$_\n"
}

use utf8;