#!/usr/bin/perl -w
# Pfade hinzufügen

#require 'additional_names.pl'; #Führt zum Abbruch

push(@INC,"../namespaces");

foreach (@INC) {print("$_\n")}

require 'additional_names.pl'; #Funktioniert an dieser Stelle weil nun im Pfad




