#!/usr/bin/perl
# Source: http://search.cpan.org/~pip/Games-Cards-Poker-1.2.565CHh5/Poker.pm

use Games::Cards::Poker;

# Deal Four (4) players hands and score them...
my $players   = 4; # number of players to get hands dealt
my $hand_size = 5; # number of cards to deal to each player
my @hands     = ();# player hand data
my @deck      = Shuffle(Deck());

while($players--) {
  push(@{$hands[$players]}, pop(@deck)) foreach(1..$hand_size);
  printf("Player$players score:%4d hand:@{$hands[$players]}\n",
                              ScoreHand(@{$hands[$players]}));
}