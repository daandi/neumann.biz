#!/usr/bin/perl -w

@ascii = (0..127);

foreach(@ascii) {
	print($_ . "->" . chr($_) . "\n");
};
