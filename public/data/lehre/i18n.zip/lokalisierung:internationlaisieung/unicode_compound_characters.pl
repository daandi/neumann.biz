#!/usr/bin/perl -w

use utf8;

@chars=("ö","ö");

foreach (@chars) {
	print "$_ -> length:".length($_)." codepoint:".ord($_)."\n";
}

foreach (@chars) {
	foreach(split(//,$_)){
		print "$_ -> length:".length($_)." codepoint:".ord($_)."\n";
	}
}

