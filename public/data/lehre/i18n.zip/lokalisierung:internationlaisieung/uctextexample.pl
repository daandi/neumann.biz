#!/usr/bin/perl -X
use utf8;

open (UNITXT,"<:utf8","unicode.txt");

while (<UNITXT>) {

#Script Arabic / Alle arabischen Wörter finden
	while ($_=~/(\p{Arabic}+)/g) {
		$ar++;
		push(@ar,$1);
	}
#Property punctuation / Satzzeichen finden
	while (/(\p{Punctuation}+)/g) {
		$punc++;
		push(@punc,$1);
	}
#Uppercase / Alle Großbuchstaben finden
	while (/(\p{Uppercase_Letter})/g) {
		$big++;
		push(@big,$1);
	}

	if (/, במיינ/) {
		print;
	}

}

print "\nDie Datei enthält $ar Wörter die aus Buchstaben des arabischen Blocks geformt sind:\n";
erg(\@ar);
print "\nDie Datei enthält $punc Punktuationszeichen:\n";
erg(\@punc);
print "\nDie Datei enthält $big Großbuchstaben:\n";
erg(\@big);


sub erg{
$list=shift;
	foreach (@$list) {
		print"$_ ";
	}
}