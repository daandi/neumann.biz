#!/usr/bin/perl -w

$moskau = "Москва́";
$北京 = "Peking"; 
$neu_delhi = "नई दिल्ली";

print length($moskau);