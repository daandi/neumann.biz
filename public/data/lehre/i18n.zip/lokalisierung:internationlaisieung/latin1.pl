#!/usr/bin/perl -w
foreach(0..255) {
	print("$_->".chr($_)."\n");
}