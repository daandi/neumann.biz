#!/usr/bin/perl -w

use utf8;

@cities = ("Москва́", "北京", "नई दिल्ली");
foreach my $city (@cities) {
	print "City: $city ->".length($city)."\n";
	
	foreach my $char (split(//,$city)) {
		print $char.":".ord($char)."\n";
	}
	
}