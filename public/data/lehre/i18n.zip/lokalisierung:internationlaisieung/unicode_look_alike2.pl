#!/usr/bin/perl -w

$as = ["А","A","Α"];

foreach(@{$as}) {
	print_char_with_codepoint($_);
}

sub print_char_with_codepoint {
	$char = shift;
	print "char:$char->"." Codepoint:".ord($char)."\n";
}