#/usr/bin/perl -w
use utf8;

$Москва́ = "Moskau";
$beijing = "北京";

λόγος($Москва́);


sub λόγος {
	my $in = shift;
	print("$in\n");
}