#!/usr/bin/perl -w
package Stein; # Package für Klasse

sub new {
    my($class, $gewicht) = @_;        # Klassenname als ersten Parameter
    my $self = { gewicht => $gewicht };  # hier befinden sich die Attribute
    bless($self, $class);          # bless macht aus Hash-Referenz eine Klasse
    return $self;
}
# Methode ohne Argumente, hat selbst stets automatisch ein Arument: die Referenz auf $self
sub da_liegen {
	$self = shift;
	print "...\n"."Der Stein liegt da mit ".$self -> {gewicht}."kg. \n"
}
# Methode mit einem Argument
sub add_graffito {
	($self,$text) = @_;
	$self ->{graffito} = $text;
}

1 # ist ein Modul