#!/usr/bin/perl -w
use Stein;
use Edelstein;
use Duck;

# Konstruktor
my $brocken = Stein->new(50);
my $smaragd = Edelstein->new(0.3,40000);
my $donald = Duck->new();

@queue = ($brocken,$smaragd,$donald);

# Duck Typing, die Stein und Edelstein sind im gleichen Vererbungsbaum, Die KLasse Duck hat einen eignen Baum. Das Programm funktioniert aber problemlos da alle Klassen die Methode da_liegen()implementieren
foreach $entry (@queue) {
	$entry->da_liegen();
}

# add_grafitto() ist zwar für Stein und Edelstein definiert aber nicht für Duck -> Laufzeitfehler 
foreach $entry (@queue) {
	$entry->add_graffito("meins!");
	print "Gravur:".$entry."->".$entry->{graffito}."\n";
}




