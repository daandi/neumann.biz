#!/usr/bin/perl -w
package Edelstein; # Package für Klasse
use base 'Stein'; # Hier wird geerbt

# Konstruktor von Stein überschrieben
sub new {
    my($class, $gewicht,$wert) = @_;        # Klassenname als ersten Parameter
    my $self = { gewicht => $gewicht, wert => $wert };  # hier befinden sich die Attribute
    bless($self, $class);          # bless macht aus Hash-Referenz eine Klasse
    return $self;
}

# Neue Methode
sub preis {
	$self = shift;
	return $self -> {wert};
}

# Methode überschrieben, aber mit super Zugriff auf Elternklasse
sub da_liegen {
	$self = shift;
	$self->SUPER::da_liegen();
	print("und ist ".$self->{wert}." wert.\n");
}
1