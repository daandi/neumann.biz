#!/usr/bin/perl -w
use Stein;

# Konstruktor
my $brocken = Stein->new(50);

# Methodenaufruf
$brocken -> da_liegen();

#Membervariable
print $brocken -> {gewicht}."\n";

#Eine Methode mit Argument verwenden
$brocken -> add_graffito("O tempore, oh mores");

# Gibt Objektnamen und Hashreferenz aus
print "$brocken\n";

