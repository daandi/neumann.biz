#!/usr/bin/perl -w
use Edelstein;

# Konstruktor
my $rubin = Edelstein->new(0.5,50000);
my $diamant = Edelstein->new(0.4,700000);

# Methodenaufruf, Implementierung in der Eleternklasse
$rubin -> da_liegen();

#Methodenaufruf, Implementierung in Klasse
print "Preis:".($diamant -> preis)."\n";

# Gibt Objektnamen und Hashreferenz aus
print "$rubin\n";
print "$diamant\n";

$diamant -> da_liegen();