#!/usr/bin/perl -w
package Duck;

sub new {
    my($class) = @_;        # Klassenname als ersten Parameter
    my $self = { gewicht => 20 };  #Vorbelegt mit 20
    bless($self, $class);
    return $self;
}
# Methode ohne Argumente, hat selbst stets automatisch ein Arument: die Referenz auf $self
sub da_liegen {
	$self = shift;
	print "...\n"."Quack, Quack.\nDie Ente wiegt  ".$self -> {gewicht}." kg. \n"
}
1 # ist ein Modul