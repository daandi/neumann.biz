#!/bin/sh
cat ./res/sentences.txt | sed 's/<\/eos>//' | perl -nE 'binmode STDIN, ":utf8"; binmode STDOUT, ":utf8"; say $1 while <> =~ /\b([[:lower:]].*?)\b/g' | sort | uniq -c | sort -nr | sed 's/^\s*//' > ~/uni/eos/eos_v2/cross/nb-NO_lower_words.txt
