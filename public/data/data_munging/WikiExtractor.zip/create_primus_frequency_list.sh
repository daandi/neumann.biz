#!/bin/sh
cat ./res/sentences.txt | perl -nE 'binmode STDIN, ":utf8"; binmode STDOUT, ":utf8"; say $1 if <> =~ /^([[:lower:][:upper:]]+?)\b/' | sort | uniq -c | sort -nr | sed 's/^\s*//' > ~/uni/eos/eos_v2/primus/primus_frequency_list_nb-NO.txt
#[a-zA-ZöäüÖÄÜøæåØÆÅéóò]
#[[:lower:][:upper:]] => besser! nimmt mehr mit!
