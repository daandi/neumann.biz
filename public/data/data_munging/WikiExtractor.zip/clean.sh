#!/bin/sh
for dir in ./stripped/*; do for file in $dir/*.txt; do echo "Cleaning $file..."; cat $file | tr "_" " " > tmp; mv tmp $file; done; done; echo "Done.";
