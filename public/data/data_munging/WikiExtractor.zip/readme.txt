Erstelle Korpus aus Wikipedia-XML und baue EOS-Listen

1. extract.sh
    res => extracted
2. strip.sh
    extracted => stripped
3. clean.sh
    stripped => stripped
4. segmentize.sh
    stripped => sentences.txt
5. create_primus_frequency_list.sh
    sentences.txt => primus_frequency_list_no.txt
6. create_lower_words.sh
    sentences.txt => no_lower_words.txt
