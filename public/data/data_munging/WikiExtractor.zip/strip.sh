#!/bin/sh
for dir in {'AA','AB','AC','AD','AE','AF','AG','AH','AI'}; do mkdir ./stripped/$dir; for i in {00..99}; do bzip2 -cdv ./extracted/$dir/wiki$i.bz2 | html2text -utf8 > ./stripped/$dir/wiki$i.txt; done; done; echo "Done.";
#for dir in ./extracted/*; do mkdir ./stripped/$dir; for file in {00..99}; do bzip2 -cdv ./extracted/$dir/wiki$file.bz2 | html2text -utf8 > ./stripped/$dir/wiki$file.txt; done; done; echo "Done.";

