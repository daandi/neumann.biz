#!/bin/sh
#for dir in ./stripped/*; do for file in $dir/*.txt; do ~/uni/eos/eos_v2/bin/eosv2 -sP -f $file -o sentences.txt; done; done; echo "Done.";
cd ~/uni/eos/eos_v2/; for dir in ~/uni/korpora/no_nb/stripped/*; do for file in $dir/*.txt; do echo "Segmentizing $file..."; ./bin/eosv2 -sP -l no -f $file >> ~/uni/korpora/no_nb/res/sentences.txt; done; done; echo "Done."; cd ~/uni/korpora/no_nb;
