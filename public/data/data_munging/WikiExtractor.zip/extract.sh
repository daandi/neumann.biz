#!/usr/bin
bzip2 -dc ./res/nowiktionary-latest-pages-articles.xml.bz2 | python WikiExtractor.py -o extracted
