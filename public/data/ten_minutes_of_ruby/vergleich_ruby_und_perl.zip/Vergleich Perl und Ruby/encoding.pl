#!/usr/bin/perl -w

open (LATIN1,"<","latin1.txt");
open (UTF8,">:utf8","utf-8.txt");

while (<LATIN1>) {
	print UTF8;
}
close LATIN1;
close UTF8;