#!/usr/bin/env perl -w
use utf8;

# Unicode ˈjuːnɪkoʊd

$unicode = "juːnɪkoʊd";
print "Länge des Strings unicode: ".length($unicode)."\n";

foreach( split($unicode,/\w/) ) {
	print $_."\n";
}
