#/usr/bin/env perl -w

sub methode {
	($a,$b) = @_;
	print "a:".$a." und b:".$b."\n";
}

methode(1,"test");
methode(3,4,5);
methode(1);