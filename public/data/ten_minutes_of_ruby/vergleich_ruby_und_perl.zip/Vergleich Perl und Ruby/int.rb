#!/usr/bin/env perl -w
use utf-8;

# Unicode ˈjuːnɪkoʊd

unicode = "juːnɪkoʊd"
puts "Erlaubtes Encoding: #{unicode.valid_encoding?}"
puts "Länge des Strings unicode: #{unicode.length}"

# Characters
unicode.each_char do |char|
   puts "#{char}"
end

