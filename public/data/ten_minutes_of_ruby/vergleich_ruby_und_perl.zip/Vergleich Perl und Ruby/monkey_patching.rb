#!/usr/bin/env ruby -w
# coding: utf-8

class Fixnum
	def the_meaning_of_life
		42
	end
end

puts 1.class
puts 1.the_meaning_of_life