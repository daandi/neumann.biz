#!/usr/bin/env ruby -w

liste = [1,2,3,4]
a = 0

liste.each  {|a| puts a *= 2}

p liste
p a

