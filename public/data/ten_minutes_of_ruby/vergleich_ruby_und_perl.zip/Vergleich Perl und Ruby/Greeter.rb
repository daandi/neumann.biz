#!/usr/bin/env ruby -w

class Greeter
    
    attr_accessor :name
    
    def initialize(name)
        @name = name
    end
    
    def say_hello
        puts "Hello #{name}"
    end
    
end

g = Greeter.new("Max")
g.say_hello