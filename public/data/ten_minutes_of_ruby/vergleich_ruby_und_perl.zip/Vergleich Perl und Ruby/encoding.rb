#!/usr/bin/env ruby
# coding: UTF-8
# Datei in Latin1 öffnen und als utf-8 bearbeiten und speichern

latin1_file = File.open "latin1.txt", "r:iso-8859-1:utf-8"
utf8_file = File.open "utf-8.txt", "w:utf-8"

latin1_file.each_line do |line|
    utf8_file << line
end