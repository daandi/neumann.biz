#!/usr/bin/env ruby -w
# coding: utf-8

%w{Baum Bär Bier Ärger}.each do |wort|
    puts wort if wort =~/är/i
end