#!/usr/bin/env perl 

package Greeter;

sub new{
    my ($class,$name) = @_;
    my $self = {
		_name => $name
    };
    bless($self, $class);
    return $self;
}

sub say_hello {
	$self=shift;
	print "Hello ".$self->{_name}."\n";
}

package main;

$g = Greeter->new("Max");
$g->say_hello();