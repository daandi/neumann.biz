#!/usr/bin/env perl -w

@liste = (1,2,3,4);
$a = 0;

foreach $a (@liste)  {
	$a = 6;
	print(($a*=2)." \n");
}

print @liste;
print $a;

