#!/usr/bin/env perl -w
use utf8;

foreach(qw(Baum Bär Bier Ärger)) {
	print $_ if $_ =~/är/i
}